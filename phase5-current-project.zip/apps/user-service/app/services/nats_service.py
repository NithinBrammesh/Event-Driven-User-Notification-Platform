import json
from datetime import datetime, timezone
from typing import Any

from nats.aio.client import Client as NATSClient

from app.core.config import settings
from app.schemas.event import UserCreatedEvent

_nats_client: NATSClient | None = None


async def get_nats_client() -> NATSClient | None:
    global _nats_client
    if _nats_client is not None:
        return _nats_client

    try:
        client = NATSClient()
        await client.connect(
            settings.nats_url,
            user=settings.nats_username or None,
            password=settings.nats_password or None,
            connect_timeout=5,
            reconnect_time_wait=1,
            max_reconnect_attempts=1,
        )
        _nats_client = client
    except Exception:
        return None
    return _nats_client


async def ensure_jetstream_stream(js) -> None:
    try:
        await js.stream_info(settings.nats_stream)
        return
    except Exception:
        pass

    try:
        await js.add_stream(name=settings.nats_stream, subjects=[settings.nats_subject])
    except Exception:
        pass


async def publish_user_event(event_type: str, user_data: dict[str, Any]) -> bool:
    nc = await get_nats_client()
    if nc is None:
        return False

    js = nc.jetstream()
    await ensure_jetstream_stream(js)

    payload = UserCreatedEvent.model_validate({
        "event_id": user_data.get("event_id"),
        "event_type": event_type,
        "user_id": user_data.get("user_id"),
        "email": user_data.get("email"),
        "created_at": user_data.get("created_at"),
    }).model_dump(mode="json")

    try:
        await js.publish(settings.nats_subject, json.dumps(payload).encode("utf-8"))
        return True
    except Exception:
        return False

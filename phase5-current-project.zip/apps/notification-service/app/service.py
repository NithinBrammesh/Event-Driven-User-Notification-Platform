import asyncio
import json
from typing import Any

from nats.aio.client import Client as NATSClient
from nats.js.api import AckPolicy, ConsumerConfig, DeliverPolicy


class NotificationService:
    def __init__(
        self,
        nats_url: str,
        stream_name: str,
        subject: str,
        consumer_name: str = "notification-service",
        nats_username: str = "",
        nats_password: str = "",
    ):
        self.nats_url = nats_url
        self.stream_name = stream_name
        self.subject = subject
        self.consumer_name = consumer_name
        self.nats_username = nats_username
        self.nats_password = nats_password
        self._client: NATSClient | None = None
        self._consumer_task: asyncio.Task | None = None
        self._last_event: dict[str, Any] | None = None
        self._seen_event_ids: set[str] = set()

    async def start(self) -> None:
        try:
            client = NATSClient()
            await client.connect(
                self.nats_url,
                user=self.nats_username or None,
                password=self.nats_password or None,
                connect_timeout=5,
                reconnect_time_wait=1,
                max_reconnect_attempts=1,
            )
            self._client = client
            js = self._client.jetstream()
            try:
                await js.stream_info(self.stream_name)
            except Exception:
                await js.add_stream(name=self.stream_name, subjects=[self.subject])
            try:
                await js.consumer_info(self.stream_name, self.consumer_name)
            except Exception:
                config = ConsumerConfig(
                    durable_name=self.consumer_name,
                    ack_policy=AckPolicy.EXPLICIT,
                    deliver_policy=DeliverPolicy.ALL,
                    filter_subject=self.subject,
                )
                await js.add_consumer(self.stream_name, config)
            self._consumer_task = asyncio.create_task(self._consume_loop(js))
        except Exception:
            self._client = None
            self._consumer_task = None

    async def stop(self) -> None:
        if self._consumer_task is not None:
            self._consumer_task.cancel()
        if self._client is not None:
            await self._client.close()

    async def _consume_loop(self, js) -> None:
        try:
            sub = await js.pull_subscribe(self.subject, stream=self.stream_name, durable=self.consumer_name)
            while True:
                msgs = await sub.fetch(1, timeout=5)
                for msg in msgs:
                    payload = json.loads(msg.data.decode("utf-8"))
                    event_id = payload.get("event_id")
                    if event_id and event_id in self._seen_event_ids:
                        await msg.ack()
                        continue
                    if event_id:
                        self._seen_event_ids.add(event_id)
                    self._last_event = payload
                    await msg.ack()
        except Exception:
            self._last_event = None

    def is_duplicate_event(self, event_id: str | None) -> bool:
        return bool(event_id and event_id in self._seen_event_ids)

    @property
    def last_event(self) -> dict[str, Any] | None:
        return self._last_event
